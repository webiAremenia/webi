import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-portfolios',
  templateUrl: './all-portfolios.component.html',
  styleUrls: ['./all-portfolios.component.css']
})
export class AllPortfoliosComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
