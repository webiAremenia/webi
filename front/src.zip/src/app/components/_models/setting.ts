export class Setting {
  key: string;
  value: {en: string, ru: string, am: string};
}
