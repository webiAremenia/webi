export class Language {
    id: string;
    value: string;
    status: string;
}
