export class Test {
  name: string;
  hayes: boolean;
}
