export class Portfolio {
  url: string;
  title: { en: string, ru: string, am: string };
  description: { en: string, ru: string, am: string };
}
