export class Page {
  id: number;
  title_en: string;
}
