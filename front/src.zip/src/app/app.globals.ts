import {Injectable} from '@angular/core';

Injectable();

export class Globals {
    queryUrl = 'http://localhost:3000/api/';
    clientUrl = 'http://localhost:3000/client/';
    imageUrl = 'http://localhost:3000/uploads/';
}


