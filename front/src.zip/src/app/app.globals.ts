import {Injectable} from '@angular/core';

Injectable();

export class Globals {
  query_url = 'http://localhost:3000/api/';
}


