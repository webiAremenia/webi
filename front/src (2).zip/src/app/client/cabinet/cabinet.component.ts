import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cabinet',
  templateUrl: './cabinet.component.html',
  styleUrls: ['./cabinet.component.css']
})
export class CabinetComponent implements OnInit {

  constructor() { }
    dropMenu=true;
  ngOnInit() {
  }
    addMenu(){
        this.dropMenu = !this.dropMenu;
    }

}
