export class Category {
    id: string;
    name: {
        en: string,
        ru: string,
        am: string
    };
}
