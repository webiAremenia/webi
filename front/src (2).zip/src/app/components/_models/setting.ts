export class Setting {
    id: string;
    key: string;
    value: {
        en: string,
        ru: string,
        am: string
    };
}
