import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multy-suggest',
  templateUrl: './multy-suggest.component.html',
  styleUrls: ['./multy-suggest.component.css']
})
export class MultySuggestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
